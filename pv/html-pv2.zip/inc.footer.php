
<footer>


    <div class="container sub-container marginTop">

        <ul class="menuF">
            <li><a href="termos-e-condicoes.html">Termos e Condições</a> </li>
            <li><a href="politica-de-privacidade.html">Política de Privacidade</a> </li>
            <li><a href="">Contato</a> </li>
        </ul>

        <div style="clear: both"></div>

    </div>

    <div class="container sub-container copy marginTop marginBottom">
        Copyright® Extermine a EP – 2017. Todos os Direitos Reservados. CNPJ: 21.617.994/0001-61
    </div>

</footer>

</body>
</html>
