<?
include('vars.php');
include('inc.header.php');
?>
 <div class="container marginTop">
  <img class="img" src="images/1.headline_principal.png">
 </div>

    <div class="container marginTop">
        <div class="video-container">
            <?= $frame_vimeo; ?>
        </div>
    </div>

    <div class="container marginTop">
      <div class="col-md-offset-3 col-md-6">
          <img class="img" src="images/2.headline_mini.png">
      </div>
    </div>

    <div class="container marginTop delay delay-parcial">
      <div class="col-md-offset-3 col-md-6">
        <a href="<?= $link; ?>" class="autorolar">
          <img class="img " src="images/3.botao de compra.png">
        </a>
      </div>
    </div>


    <div class="container marginTop delay">
      <div class="col-md-offset-3 col-md-6">
        <img class="img " src="images/BANNER ALT 2.png">

      </div>
    </div>


    <div class="container marginTop delay delay-parcial">
        <div class="col-md-offset-3 col-md-6">
          <a href="<?= $link; ?>" class="autorolar">
            <img class="img" src="images/3.botao de compra 3.png">
          </a>
        </div>
    </div>



	<div class="container sub-container marginTop delay">
        <div class="col-md-offset-3 col-md-6">
            <img class="img " src="images/headline 10.png">
        </div>
    </div>


	

<div class="container marginTop delay">
  <div class="box-facebook">

    <div id="comentarios_face"><span class="titulo_comentario">32 comentários</span>


      <div class="perfil"><span class="nome"><img src="http://destruindoaejaculacaoprecoce.com/wp-content/uploads/2017/05/paulo-borges.jpg" alt="">José Paulo Faria</span>
        <p>Boa noite! E aí, como faço? Quero comprar... alguém ai já comprou e sabe me dizer se não é furada?</p>
        <span class="infos">Responder · Curtir · Seguir · 30 min</span></div>

      <div class="perfil perfil2"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-3.png" alt="">Fernando Elias</span>
        <p>Fala rapaz, eu comprei tem uns 15 dias José Paulo, aqui pra mim chegou direitinho no meu email, senha e login, acesso direto na área de membros, show de bola meu amigo...Paguei no Cartão, porque recebe na hora. E pra mim tá funcionando bem demais, minha esposa tá adorando 😂😂😂</p>
        <span class="infos">Responder · Curtir · Seguir · 31 min</span></div>

      <div class="perfil perfil2"><span class="nome"><img src="http://destruindoaejaculacaoprecoce.com/wp-content/uploads/2017/05/paulo-borges.jpg" alt="">José Paulo Faria</span>
        <p>Nossa meu caro, é disso que eu to precisando também 😂😂 a mulher tá me atormentando que não aguenta mais eu queimar a largada toda hora, valeu demais ai pela ajuda, vamos que vamos 👍</p>
        <span class="infos">Responder · Curtir · Seguir · 37 min</span></div>

      <div class="perfil perfil2"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-3.png" alt="">Fernando Elias</span>
        <p>Entendo amigo, a minha também já tava nervosa comigo... esse Guia do Mateus foi uma benção, graças a Deus deu certo e melhorei em poucas semanas, e tem que fazer tudo certinho. Não tem erro!!! </p>
        <span class="infos">Responder · Curtir · Seguir · 41 min</span></div>

      <div class="perfil"><span class="nome"><img src="http://destruindoaejaculacaoprecoce.com/wp-content/uploads/2017/05/jose-vitor-sampaio.jpg" alt="">Maurício Fernandes</span>
        <p>Achei que era só comigo que a mulher andava tensa hehehe elas não querem saber de desculpas mais não...também, 16 anos juntos, tem que satisfazer né, senão complica. Mas vou parar de perder tempo com cremes e truques fajutos, e comprar o método italiano logo pq ela merece.. e eu quero me sentir vivo e forte novamente....</p>
        <span class="infos">Responder · Curtir · Seguir · 24 min</span></div>

      <div class="perfil"><span class="nome"><img src="http://destruindoaejaculacaoprecoce.com/wp-content/uploads/2017/05/ivan-junior.jpg" alt="">Ademir Junior</span>
        <p>Pois é, eu demorei a comprar porque achava que era só mais um desses rolos que tem na internet todo dia... só comprei pq meu irmão comprou também e que era seguro, chegou no e-mail dele e funcionou, o que é o mais importante! Achei a compra bem segura e deu tudo certo, então, recomendo porque passar vergonha na cama é terrível...</p>
        <span class="infos">Responder · Curtir · Seguir · 29 min</span></div>

      <div class="perfil"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-5.png" alt="">Paulo Freitas Gomes</span>
        <p>Mateus, tudo certo? E aí, depois que eu comprar demora quanto tempo pra chegar meu amigo?</p>
        <span class="infos">Responder · Curtir · Seguir · 13 min</span></div>

      <div class="perfil perfil2"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-2.png" alt="">Rafael Pereira</span>
        <p>Paulo... eu comprei no cartão e chegou em 2 minutinhos, no e-mail que usei na compra, quando preenchi meus dados. Mas acho que se comprar no boleto demora mais um pouco porque tem o prazo de compensação pelo banco, por este motivo, eu comprei no Cartão de Crédito mesmo. Achei o site confiável, tudo certo, com garantia e tudo. </p>
        <span class="infos">Responder · Curtir · Seguir · 20 min</span></div>

      <div class="perfil"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-4.png" alt="">Bruno Barbosa</span>
        <p>Rapaz, o negócio é bom demais! Feliz pela minha decisão e ter tomado atitude nesse assunto que atrapalhou minha vida por tanto tempo.  Queria aguentar pelo menos uns 10 minutos, mas agora, as vezes consigo até 20 minutos e tem só uns 20 dias que comecei. O negócio agora é fazer igual o Mateus orientou no Guia, e vou correr atrás de uma academia pra aguentar o tranco 💪 </p>
        <span class="infos">Responder · Curtir · Seguir · 22 min</span></div>

      <div class="perfil"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-9.png" alt="">Flávio Correa </span>
        <p>Mano, que coisa boa!</p>
        <span class="infos">Responder · Curtir · Seguir · 39 min</span></div>

      <div class="perfil perfil2"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-11.png" alt="">Mariana Moreira</span>
        <p>Nossa, que legal! Não creio...nem sei como vim parar aqui nessa página enquanto navegava pelo Face! rsrsrs mas to achando interessante, quem sabe compro pro meu namorado também 😍😍😍</p>
        <span class="infos">Responder · Curtir · Seguir · 41 min</span></div>
      <div class="perfil perfil2"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-6.png" alt="">André Lima<strong>&nbsp;</strong></span>
        <p>Hehehe ótima ideia Aline, pode comprar que você não vai se arrepender não... garanto.</p>
        <span class="infos">Responder · Curtir · Seguir · 55 min </span></div>
      <div class="perfil"><span class="nome"><img src="http://destruindoaejaculacaoprecoce.com/wp-content/uploads/2017/05/mauro-marcondes.jpg" alt="">Vinicius Santos<strong>&nbsp;</strong></span>
        <p>Oi pessoal, pelo que eu to vendo o problema é mais comum do que eu pensei... achei que era só eu... tá complicada a coisa, vou tomar atitude logo, parar de enrolar. </p>
        <span class="infos">Responder · Curtir · Seguir · 11 min </span>
      </div>
      <div class="perfil"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-8.png" alt="">Conrado Azevedo<strong>&nbsp;</strong></span>
        <p>Rapaz, numa boa, compensa muito esse negócio. É muito bom... negócio é o cara pegar e fazer direitnho...não adianta achar que é um milagre, que é só comprar e deixar lá que a coisa funciona...ai depois sai reclamando que não funciona. Tem que seguir o passo a passo, simples e direto ao ponto. Não tem outro jeito não... quer durar mais de 30 min. sem seguir o Guia, aí não né amigo... rs</p>
        <span class="infos">Responder · Curtir · Seguir · 40 min </span>
      </div>
      <div class="perfil"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-1.png" alt="">Saulo Galvão <strong>&nbsp;</strong></span>
        <p>Galera, alguém aqui já acessou a área de membros e deu tudo certo? Tenho medo de deixar os guias no meu computador e alguém ver...</p>
        <span class="infos">Responder · Curtir · Seguir · 51 min </span>
      </div>
      <div class="perfil perfil2"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-10.png" alt="">Eduardo José <strong>&nbsp;</strong></span>
        <p>Fala Saulo, firmeza? Eu acessei e foi top, porque eu entro, uso e saio da área quando bem quero e não salvei nada no meu computador. Outro dia eu tava na rua, ia encontrar uma gata e dei uma olhada no Plano de Emergência, foi bom, me ajudou com umas dicas e já valeu o investimento...kkkkk</p>
        <span class="infos">Responder · Curtir · Seguir · 12 min </span>
      </div>
      <div class="perfil perfil2"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-1.png" alt="">Saulo Galvão  <strong>&nbsp;</strong></span>
        <p>Massa, aí sim, mandou bem Eduardo! Valeu! </p>
        <span class="infos">Responder · Curtir · Seguir · 29 min </span>
      </div>
      <div class="perfil"><span class="nome"><img src="http://destruindoaejaculacaoprecoce.com/wp-content/uploads/2017/05/joao-ribeiro-silva.jpg" alt="">Lucas Silva  <strong>&nbsp;</strong></span>
        <p>Salve galera, como faço para adquirir? Também quero colocar em prática! Cansei de passar vergonha... virar o jogo logo e curtir a vida direito. Pra cima... </p>
        <span class="infos">Responder · Curtir · Seguir · 14 min </span>
      </div>
      <div class="perfil"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-7.png" alt="">Rogério Dantas <strong>&nbsp;</strong></span>
        <p>Lucas, só clicar aí e comprar no cartão mesmo que chega na hora. Começa hoje mano, não perde tempo não, qualquer cara tem condições de pagar por isso, tá muito justo o valor pelo tanto que o Guia é bem feito e resolve. </p>
        <span class="infos">Responder · Curtir · Seguir · 19 min </span>
      </div>
      <div class="perfil"><span class="nome"><img src="http://www.destruindoaep.com/wp-content/uploads/2017/06/coment-12.jpg" alt="">Josué Marins  <strong>&nbsp;</strong></span>
        <p>Quero te agradecer em público Mateus, você é o cara mesmo! Valeu cada centavo, que pra falar a real, tá barato mesmo... mas não precisa aumentar o preço...kkkk como vc disse, o negócio é ajudar a galera a sair dessa situação que como vc sabe, é chata pra caramba. Parabéns pelo seu trabalho... tamo junto! </p>
        <span class="infos">Responder · Curtir · Seguir · 46 min </span>
      </div>
    </div>


  </div>
</div>

<div class="delay delay-parcial">
  <span id="timer_minutos"></span>
  <span id="timer_segundos"></span>

  <div class="container marginTop">
      <div class="col-md-offset-3 col-md-6">
        <a href="<?= $link; ?>" class="link">
          <img class="img preco" src="images/banner ancoragem 1_com selos.png">
        </a>
      </div>
  </div>


  <div class="container marginTop img preco">
      <div class="col-md-offset-3 col-md-6">
          <img class="img" src="images/garantia.png">
      </div>
  </div>

</div>

<?
include('inc.artigo-oculto.php');
include('inc.footer.php');
?>

<script>

    /* Back Redirect (@tihhgoncalves) */
    var back_redirect_back_link = '<?= $linkBackRedirect;  ?>';

    history.pushState({},"",location.href);
    history.pushState({},"",location.href);

    window.onpopstate = function(){
        setTimeout(function () {
            location.href = back_redirect_back_link;
        },1);
    };

    /* Autoplay (@tihhgoncalves) */
    $(document).ready(function(){

        var autoplay = false;

        $(window).scroll(function(){

            if ($(this).scrollTop() >= 100) {

                if(!autoplay) {
                    $("iframe")[0].src += "?autoplay=1";
                    autoplay = true;
                }
            }

        });

    });


<?
switch($delayTipo){

  case 0:
    $class_delay = null;
    break;

  case 1:
    $class_delay = '.delay';
    break;

  case 2:
    $class_delay = '.delay-parcial';
    break;

}

if($delayTipo != 0){

?>
    /*DELAY*/
    $(document).ready(function () {


      var tempo_delay = (1000 * 60 * 5); //min
//  var tempo_delay = 1000;

      //$('<?= $class_delay; ?>').css('opacity', 0);
      $('<?= $class_delay; ?>').hide();


      setTimeout(function () {
        $('<?= $class_delay; ?>').fadeIn('slow', function () {

          timer_ajusta();


        });
      }, tempo_delay);
    });
    <?
}
    ?>

    /* BTN COMPRAR AUTOROLAR */
    $(document).ready(function(){

      $('a.autorolar').click(function(e){

        var preco_top = $('img.preco').offset().top;
        $('html,body').animate({scrollTop: preco_top}, 1000);

        e.preventDefault();
        e.stopPropagation();

      });

    });
</script>