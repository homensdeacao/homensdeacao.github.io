<?
$page_title = 'PV Mob-2';
$link = 'https://app.monetizze.com.br/r/BYS146531';
$frame_vimeo = '<iframe src="https://player.vimeo.com/video/246682991" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
$linkBackRedirect = 'http://saudedohomemoficial.com.br';
$delayTipo = 2; // 0 = nenhuma / 1 = 100% / 2 = parcial
?>